SELECT
  collision_type,
  COUNT(*) AS total_claims,
  AVG(CAST(total_claim_amount AS FLOAT)) AS avg_claim_amount,
  AVG(CAST(policy_annual_premium AS FLOAT)) AS avg_policy_premium,
  SUM(CASE WHEN fraud_reported = 1 THEN 1 ELSE 0 END) AS fraud_cases,
  100.0 * SUM(CASE WHEN fraud_reported = 1 THEN 1 ELSE 0 END) / COUNT(*) AS fraud_rate_pct
FROM insurance_claims
GROUP BY collision_type
ORDER BY fraud_rate_pct DESC;
